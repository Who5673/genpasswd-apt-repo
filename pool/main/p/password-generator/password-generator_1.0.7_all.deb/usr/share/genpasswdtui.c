#define __POSIX_C_SOURCE 200809L
#define NUM_OPTIONS 4
#define NUM_OPTIONS_TWO 3
#include <ctype.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/random.h>
#include <ncurses.h>

// Generate password:
void generate_password(char *output, unsigned short length) {
  const char charset[] = 
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789"
    "!@#$%^&*()-_=+[]{}|;:,.<>?/";
  int charset_size = sizeof(charset) - 1; 
  unsigned char buffer[length];
  // Random strings from kernel (safe)
  if (getrandom(buffer, length, 0) == -1) {
    perror("getrandom failed");
    exit(1);
  }
  for (int i = 0; i < length; i++) {
    int index = buffer[i] % charset_size;
    output[i] = charset[index];
  }
  output[length] = '\0'; // End strings, the password is ready!
}

// Lists:
const char *options[NUM_OPTIONS] = {
  "Create a recommended password (length = 24 strings)",
  "Create a custom password with a custom amount of length",
  "Delete logs (work in progress)",
  "Get help",
};

const char *options2[NUM_OPTIONS_TWO] = {
  "Get help with genpasswd in MANPAGE",
  "Get help with genpasswd in app",
  "Get help with genpasswd in CLI interface (work in progress)",
};

void draw_ascii() {
  init_pair(10, COLOR_YELLOW, COLOR_BLACK);
  FILE *fp = popen("figlet genpasswd | boxes -d parchment", "r");
  if (fp == NULL) {
    endwin();
    perror("figlet failed");
    exit(1);
  }
  char line[256];
  attron(A_BOLD | COLOR_PAIR(10));
  short dow = 1;
  while (fgets(line, sizeof(line), fp) != NULL) {
    mvprintw(dow++, 4, "%s", line);
  }
  attroff(A_BOLD | COLOR_PAIR(10));
  pclose(fp);
}

// Draw menu func:
void draw_manu(short highlight) {
  short int rows, cols;
  getmaxyx(stdscr, rows, cols);

  init_pair(5, COLOR_BLUE, COLOR_WHITE);
  init_pair(10, COLOR_YELLOW, COLOR_BLACK);
  init_pair(1, COLOR_RED, COLOR_BLACK);
  clear();

  /* "Press q to quit" header  */
  attron(A_BOLD | COLOR_PAIR(1));
  char *quiting = "Press q to quit this program";
  unsigned short lenquit = strlen(quiting);
  short quitrow = rows*0;
  unsigned int quitcol = cols / 2 - (lenquit / 2);
  mvprintw(quitrow, quitcol, "%s", quiting);
  attroff(A_BOLD | COLOR_PAIR(1));

  draw_ascii(); 

  for (short i = 0; i < NUM_OPTIONS; i++) {
    if (i == highlight) 
      attron(A_REVERSE | COLOR_PAIR(5));
    mvprintw(12 + i, 4, "%s", options[i]);
    if (i == highlight)
      attroff(A_REVERSE | COLOR_PAIR(5));
  }
  refresh();
}
// Another charset of the menu:
void draw_manu2(short highlight) {
  init_pair(5, COLOR_BLUE, COLOR_WHITE);
  init_pair(10, COLOR_YELLOW, COLOR_BLACK);
  clear();

  draw_ascii();

  for (short j = 0; j < NUM_OPTIONS_TWO; j++) {
    if (j == highlight) 
      attron(A_REVERSE | COLOR_PAIR(5));
    mvprintw(12 + j, 5, "%s", options2[j]);
    if (j == highlight) 
      attroff(A_REVERSE | COLOR_PAIR(5));
  } refresh();
}
void password_genpasswd(short length) {
  init_pair(8, COLOR_GREEN, COLOR_BLACK);
  init_pair(7, COLOR_YELLOW, COLOR_BLACK);
  init_pair(6, COLOR_WHITE, COLOR_BLACK);
  init_pair(4, COLOR_RED, COLOR_BLACK);
  init_pair(2, COLOR_BLUE, COLOR_BLACK);
  init_pair(11, COLOR_MAGENTA, COLOR_BLACK);
  init_pair(12, COLOR_WHITE, COLOR_BLACK);
  char password[150];
  generate_password(password, length);
  attron(A_BOLD | COLOR_PAIR(2));
  mvprintw(15, 5, "Generated strong password: ");
  attroff(A_BOLD | COLOR_PAIR(2));
  attron(A_BOLD | COLOR_PAIR(6));
  mvprintw(17, 5, "----->     ");
  attroff(A_BOLD | COLOR_PAIR(6));
  attron(A_BOLD | COLOR_PAIR(7));
  mvprintw(17, 16, "%s", password);
  attroff(A_BOLD | COLOR_PAIR(7));
  attron(A_BOLD | COLOR_PAIR(4));
  mvprintw(19, 5, "WARNING: DO NOT SHARE THAT PASSWORD TO ANYONE! THAT THING NEEDS TO BE YOUR SECRET");
  attroff(A_BOLD | COLOR_PAIR(4));
  attron(A_BOLD | COLOR_PAIR(11));
  mvprintw(23, 5, "Please write the application/local User that you want to use password for (leave empty = NO LOGGING)?");
  mvprintw(24, 5, "Account/app/webaccount:");
  attroff(A_BOLD | COLOR_PAIR(11));
  move(24, 16);
  char applog[30];
  echo();
  curs_set(TRUE);
  attron(COLOR_PAIR(12));
  wgetnstr(stdscr, applog, 30);
  attroff(COLOR_PAIR(12));
  noecho();
  if (strcmp(applog, "") != 0) {
    system("sudo chattr -i -a /var/log/secrof.log");
    FILE *fd = fopen("/var/log/secrof.log", "a");
    fprintf(fd, "password %s appended for %s\n", password, applog);
    fclose(fd);
    system("sudo chattr +i +a /var/log/secrof.log");
  }
  curs_set(FALSE);
  attron(A_BOLD | COLOR_PAIR(8));
  if (strcmp(applog, "") != 0) mvprintw(28, 5, "Sucessfully write the log. Press any key to go back...");
  else mvprintw(28, 5, "Press any key to go back...");
  attroff(A_BOLD | COLOR_PAIR(8));
}

void draw_buttonsformouse() {
   short rows, cols;
   getmaxyx(stdscr, rows, cols);
   char *buttonup = "<UP>";
   char *buttondown = "<DOWN>";
   mvprintw(rows - (rows / 4), cols / 4, "%s", buttonup);
   mvprintw(rows - (rows / 4), cols - (cols / 4), "%s", buttondown);
   refresh();
}
// Main scripts
int main(int args, char *argv[]) {
  if (args > 2) {
    printf("Error: Invalid syntax!\n");
    printf("\033[1;34mUsage: genpasswdtui [OPTIONS]\033[0m\n");
    printf("\033[1;37mSee our manpage or use 'genpasswdtui -h' for help. Note: No mouse mode is being worked in progess so you cannot enable it.\033[0m\n");
    return 1;
  } 
  else if (args == 2){
    if (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0) {
      printf("\033[1;34mUsage: genpasswdtui [OPTIONS]\033[0m\n");
      printf("Options in genpasswdtui are: \n");
      printf("\033[1;32m\t--help, -h: \033[0m");
      printf("\033[1;36mGet the instructions fast so that you know some OPTIONS to deal with genpasswdtui (color mode)\033[0m\n");
      printf("\033[1;32m\tget-help: \033[0m");
      printf("\033[1;36mPrints the instructions verbosely so that you learn more skills to deal with genpasswdtui (no-color mode)\033[0m\n");
      printf("\033[1;32m\t--no-mouse, -nm, no-mouse-mode=enabled, no-mouse-mode=yes, no-mouse-mode=true, no-mouse-mode=1: \033[0m");
      printf("\033[1;36m(Work in progress) Enable no-mouse mode so that you only can control the app via keyboard\033[0m\n");
      printf("Should you want more information, please see our manpage using this command: 'man genpasswdtui'\n");
      return 0;
    } else if (strcmp(argv[1], "--version") == 0) {
      printf("\033[1;38;2;255;165;0mgenpasswdtui 1.0.8\033[0m\n"); 
      return 0;
    } else if (strcmp(argv[1], "get-help") == 0) {
      printf("genpasswdtui is a Text-based User Interface and open-source app that generates strong passwords without using the Internet in the system.\n");
      printf("This is the way to use the options in that app:\n");
      printf("");
      printf("\t genpasswd [OPTIONS]\n");
      printf("\n");
      printf("--help -h: Get the instructions fast, so you can use the app easily. Has colors\n");
      printf("\n");
      printf("get-help: More verbose instructions to help you but with no color\n");
      printf("\n");
      printf("--version: Show the version of Password Generator package\n");
      printf("\n");
      printf("-nm --no-mouse no-mouse-mode=enabled no-mouse-mode=yes no-mouse-mode=true no-mouse-mode=1: ");
      printf("(Work in progress) Enable no-mouse mode so that only keyboard can interact with options in genpasswdtui\n");
      printf("\n");
      printf("With the GPLv3 License (genpasswd-LICENSE) in /usr/share, do not make a copyright of this app, but you are allowed o help us develop ");
      printf("the app so that genpasswdtui will fix bugs faster and new options will be invented.\n");
      printf("\n");
      printf("THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF ");
      printf("MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ");
      printf("ANY CLAIM, DAMAGES OR OTHER  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH ");
      printf("THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\n");
      printf("\n");
      printf("Should you want more information, please see our manpage using this command: 'man genpasswdtui'\n");
      return 0;
    }
    else {
      printf("Error: Invalid syntax!\n");
      printf("\033[1;34mUsage: genpasswdtui [OPTIONS]\033[0m\n");
      printf("\033[1;37mSee our manpage or use 'genpasswdtui -h' for help. Note: No mouse mode is being worked in progess so you cannot enable it.\033[0m\n");
      return 1;
    }
  }
  
  // Basic info about the window:
  MEVENT event;
  initscr();
  cbreak();
  noecho();
  curs_set(FALSE);
  keypad(stdscr, TRUE);
  short choice = 0;
  short choicehai = 0;
  mousemask(ALL_MOUSE_EVENTS | REPORT_MOUSE_POSITION, NULL);

  // Get window winfo:
  //long int rows, cols;
  //getmaxyx(stdscr, rows, cols);
  
  // Define some color pairs:
  start_color();
  init_pair(2, COLOR_BLUE, COLOR_BLACK);
  init_pair(3, COLOR_GREEN, COLOR_BLACK);
  init_pair(4, COLOR_RED, COLOR_BLACK);
  init_pair(6, COLOR_WHITE, COLOR_BLACK);
  init_pair(7, COLOR_YELLOW, COLOR_BLACK);
  init_pair(8, COLOR_GREEN, COLOR_BLACK);
  init_pair(10, COLOR_YELLOW, COLOR_BLACK);

  
  // Process
  int ch;
  draw_manu(choice);
  while (1) {
    ch = getch();
    if (ch == 'q') {
      break;
    }
    switch (ch) {
      case KEY_MOUSE:
        if (getmouse(&event) == OK) {
          //short x = event.x;
          //short y = event.y;
        }
      case KEY_UP: 
        if (choice > 0) {
          choice--;
        }
        break;
      case KEY_DOWN:
        if (choice < NUM_OPTIONS - 1) { choice++; }
        break;
      case 10: // Enter
      case KEY_RIGHT:
        clear();
        if (choice == 0) {
          draw_ascii();
          password_genpasswd(24);
          refresh();
          getch();
        } else if (choice == 1) {
          draw_ascii();
          attron(COLOR_PAIR(8));
          mvprintw(12, 5, "Please take down the number you want to (ASCII table will need to be used if you write a character in here except an integer, q to return to main menu): ");
          attroff(COLOR_PAIR(8));
          move(13, 5);
          char length[100]; char *endptr; char *trimmed;
          echo();
          curs_set(TRUE);
          wgetnstr(stdscr, length, 2);
          if (strcmp(length, "q") == 0) break;
          trimmed = length;
          while (isspace(*trimmed)) trimmed++;
          short result = strtol(trimmed, &endptr, 10);
          while (strcmp(length, " ") == 0 || endptr == trimmed || *endptr != '\0' || result > 100 || result < 13) {
            noecho();
            curs_set(0);
            attron(A_BOLD | COLOR_PAIR(4));
            mvprintw(15, 5, "Invalid input! Input must be an unsigned short and not to be greater than 100 or lower than 13. Press any key to try again.");
            attroff(A_BOLD | COLOR_PAIR(4));
            clrtoeol();
            refresh();
            getch();
            clear();
            draw_ascii();
            attron(COLOR_PAIR(8));
            mvprintw(12, 5, "Please take down the number you want to (ASCII table will need to be used if you write a character in here except an integer): ");
            attroff(COLOR_PAIR(8));
            move(13, 5);
            char length[100]; char *endptr; char *trimmed;
            echo();
            curs_set(TRUE);
            wgetnstr(stdscr, length, 2);
            if (strcmp(length, "q")) break;
            trimmed = length;
            while (isspace(*trimmed)) trimmed++;
            short result = strtol(trimmed, &endptr, 10);
          } 
          clear();
          draw_ascii();
          password_genpasswd(result);
          refresh();
          getch();
        }
        else if (choice == 3) {
            clear();
            draw_manu2(choicehai);
            while (1) {
              ch = getch();
              if (ch == KEY_LEFT) break;
              switch (ch) {
                case KEY_UP:
                  if (choicehai > 0) choicehai--;
                  break;
                case KEY_DOWN:
                  if (choicehai < NUM_OPTIONS_TWO - 1) choicehai++;
                  break;
                case 10:
                case KEY_RIGHT:
                  if (choicehai == 0) {
                    clear(); // Enter
                    endwin();
                    system("man genpasswdtui");
                    refresh();
                    break;
                  }
                  else if (choicehai == 1) {
                    clear();
                    draw_ascii();
                    mvprintw(12, 5, "genpasstui app.");
                    mvprintw(13, 5, "genpasstui is a Text-based User Interface app for generating secure passwords to protect you from being attacked in the security.");
                    mvprintw(14, 5, "Here are some options:");
                    mvprintw(15, 5, "\t(Run with no arguments): Normally run the app with no mouse mode is enabled (as no mouse mode is being worked in place)");
                    mvprintw(16, 5, "\t--help, -h, get-help: Get help with genpasswdtui in Command Line interface to see how to use OPTIONS fast");
                    mvprintw(17, 5, "\t--no-mouse no-mouse-mode=enabled no-mouse-mode=yes -nm: (Work in progress) Run the app with no-mouse mode which options can only be interacted via keyboard");
                    mvprintw(18, 5, "Should you have more info, please see our manpage using this command: 'man genpasswdtui'.");
                    refresh();
                    getch();
                    break;
                  }
              
              }
              draw_manu2(choicehai);
            }
        }
        /*else {
          mvprintw(10, 5, "Test: %s", options[choice]);
          refresh();
          getch();
        }*/
        break;
    }
    draw_manu(choice);
  }
  endwin();
  FILE *gf = popen("echo $DISPLAY", "r");
  char buffer[255];
  char *abc = fgets(buffer, 255, gf);
  buffer[strcspn(buffer, "\n")] = 0;
  if (strcmp(abc, "") == 0) {
    system("clear");
  } pclose(gf);
  return 0;
}
